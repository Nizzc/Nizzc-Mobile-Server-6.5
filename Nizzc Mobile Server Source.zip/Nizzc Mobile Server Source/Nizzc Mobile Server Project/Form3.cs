﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace Nizzc_Collection
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            Close();
        }
        private void label1_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
        }
        private void Form3_Load_1(object sender, EventArgs e)
        {
        }
        private void label4_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void label1_Click_1(object sender, EventArgs e)
        {
            Close();
        }
        private void label3_Click(object sender, EventArgs e)
        {
            Close();
        }
        }
    }
