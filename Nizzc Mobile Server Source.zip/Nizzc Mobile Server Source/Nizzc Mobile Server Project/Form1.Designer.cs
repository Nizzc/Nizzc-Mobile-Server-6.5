﻿namespace Nizzc_Mobile_Ser
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.master = new System.Windows.Forms.TextBox();
            this.eng = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.sts = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.messg = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.cpanelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.ChildBot1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ProtectionBot1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ForwarderBot1 = new System.Windows.Forms.ToolStripMenuItem();
            this.AntiDCBot1 = new System.Windows.Forms.ToolStripMenuItem();
            this.AntiFloodBot1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RoomBot1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RoomFullerBot1 = new System.Windows.Forms.ToolStripMenuItem();
            this.OptimizerBot1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MTA_Server = new System.Windows.Forms.ToolStripMenuItem();
            this.myBotsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.coloroption = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.tagsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.forumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.abooot = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.hostcheck = new System.Windows.Forms.CheckBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.reg = new System.Windows.Forms.RichTextBox();
            this.user = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.commandlist = new System.Windows.Forms.RichTextBox();
            this.commandmsglist = new System.Windows.Forms.RichTextBox();
            this.tagstimer = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.adminhelp = new System.Windows.Forms.RichTextBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.button8 = new System.Windows.Forms.Button();
            this.NetFreeCheckBox = new System.Windows.Forms.CheckBox();
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.ErrorLable = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.button00 = new System.Windows.Forms.Button();
            this.forwadercpanle = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.originalHELP = new System.Windows.Forms.RichTextBox();
            this.WaringLabel = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.childbotcommands = new System.Windows.Forms.RichTextBox();
            this.childbotEng = new System.Windows.Forms.RichTextBox();
            this.hlp = new System.Windows.Forms.RichTextBox();
            this.hlp2 = new System.Windows.Forms.RichTextBox();
            this.spOriginalHELP = new System.Windows.Forms.RichTextBox();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // master
            // 
            this.master.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.master.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.master, "master");
            this.master.ForeColor = System.Drawing.Color.DimGray;
            this.master.Name = "master";
            this.toolTip1.SetToolTip(this.master, resources.GetString("master.ToolTip"));
            this.master.TextChanged += new System.EventHandler(this.master_TextChanged);
            // 
            // eng
            // 
            this.eng.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.eng.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.eng.ForeColor = System.Drawing.Color.Blue;
            resources.ApplyResources(this.eng, "eng");
            this.eng.Name = "eng";
            this.toolTip1.SetToolTip(this.eng, resources.GetString("eng.ToolTip"));
            this.eng.TextChanged += new System.EventHandler(this.eng_TextChanged);
            // 
            // listView1
            // 
            resources.ApplyResources(this.listView1, "listView1");
            this.listView1.Name = "listView1";
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.textBox3, "textBox3");
            this.textBox3.Name = "textBox3";
            this.toolTip1.SetToolTip(this.textBox3, resources.GetString("textBox3.ToolTip"));
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.textBox2, "textBox2");
            this.textBox2.Name = "textBox2";
            this.toolTip1.SetToolTip(this.textBox2, resources.GetString("textBox2.ToolTip"));
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.Name = "textBox1";
            this.toolTip1.SetToolTip(this.textBox1, resources.GetString("textBox1.ToolTip"));
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            resources.ApplyResources(this.button1, "button1");
            this.button1.ForeColor = System.Drawing.Color.OldLace;
            this.button1.Name = "button1";
            this.toolTip1.SetToolTip(this.button1, resources.GetString("button1.ToolTip"));
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // sts
            // 
            this.sts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sts.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.sts, "sts");
            this.sts.Name = "sts";
            this.toolTip1.SetToolTip(this.sts, resources.GetString("sts.ToolTip"));
            this.sts.TextChanged += new System.EventHandler(this.sts_TextChanged);
            this.sts.KeyDown += new System.Windows.Forms.KeyEventHandler(this.sts_KeyDown);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.button2, "button2");
            this.button2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button2.Name = "button2";
            this.toolTip1.SetToolTip(this.button2, resources.GetString("button2.ToolTip"));
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // checkBox1
            // 
            resources.ApplyResources(this.checkBox1, "checkBox1");
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            resources.ApplyResources(this.checkBox2, "checkBox2");
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Name = "label4";
            // 
            // messg
            // 
            this.messg.BackColor = System.Drawing.Color.Fuchsia;
            resources.ApplyResources(this.messg, "messg");
            this.messg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.messg.ForeColor = System.Drawing.Color.Black;
            this.messg.Name = "messg";
            this.messg.TextChanged += new System.EventHandler(this.messg_TextChanged);
            this.messg.MouseMove += new System.Windows.Forms.MouseEventHandler(this.messg_MouseMove);
            this.messg.Click += new System.EventHandler(this.messg_Click);
            this.messg.MouseDown += new System.Windows.Forms.MouseEventHandler(this.messg_MouseDown);
            this.messg.MouseUp += new System.Windows.Forms.MouseEventHandler(this.messg_MouseUp);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gray;
            this.button3.ContextMenuStrip = this.contextMenuStrip1;
            resources.ApplyResources(this.button3, "button3");
            this.button3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button3.Name = "button3";
            this.toolTip1.SetToolTip(this.button3, resources.GetString("button3.ToolTip"));
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.AllowMerge = false;
            this.contextMenuStrip1.BackColor = System.Drawing.Color.Aqua;
            resources.ApplyResources(this.contextMenuStrip1, "contextMenuStrip1");
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.toolStripMenuItem7,
            this.cpanelToolStripMenuItem,
            this.toolStripMenuItem8,
            this.toolStripMenuItem2,
            this.toolStripMenuItem6,
            this.myBotsToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem,
            this.coloroption,
            this.toolStripMenuItem4,
            this.toolStripMenuItem3,
            this.toolStripMenuItem5,
            this.aboutToolStripMenuItem});
            this.contextMenuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table;
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.contextMenuStrip1.ShowImageMargin = false;
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.AutoToolTip = true;
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            resources.ApplyResources(this.openToolStripMenuItem, "openToolStripMenuItem");
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.AutoToolTip = true;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            resources.ApplyResources(this.toolStripMenuItem7, "toolStripMenuItem7");
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // cpanelToolStripMenuItem
            // 
            this.cpanelToolStripMenuItem.Name = "cpanelToolStripMenuItem";
            resources.ApplyResources(this.cpanelToolStripMenuItem, "cpanelToolStripMenuItem");
            this.cpanelToolStripMenuItem.Click += new System.EventHandler(this.cpanelToolStripMenuItem_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            resources.ApplyResources(this.toolStripMenuItem8, "toolStripMenuItem8");
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            resources.ApplyResources(this.toolStripMenuItem2, "toolStripMenuItem2");
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.BackColor = System.Drawing.Color.Cyan;
            this.toolStripMenuItem6.CheckOnClick = true;
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ChildBot1,
            this.ProtectionBot1,
            this.ForwarderBot1,
            this.AntiDCBot1,
            this.AntiFloodBot1,
            this.RoomBot1,
            this.RoomFullerBot1,
            this.OptimizerBot1,
            this.MTA_Server});
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            resources.ApplyResources(this.toolStripMenuItem6, "toolStripMenuItem6");
            // 
            // ChildBot1
            // 
            this.ChildBot1.BackColor = System.Drawing.Color.Cyan;
            this.ChildBot1.Checked = true;
            this.ChildBot1.CheckOnClick = true;
            this.ChildBot1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChildBot1.Name = "ChildBot1";
            resources.ApplyResources(this.ChildBot1, "ChildBot1");
            this.ChildBot1.Click += new System.EventHandler(this.ChildBot1_Click);
            // 
            // ProtectionBot1
            // 
            this.ProtectionBot1.BackColor = System.Drawing.Color.Cyan;
            this.ProtectionBot1.Checked = true;
            this.ProtectionBot1.CheckOnClick = true;
            this.ProtectionBot1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ProtectionBot1.Name = "ProtectionBot1";
            resources.ApplyResources(this.ProtectionBot1, "ProtectionBot1");
            this.ProtectionBot1.Click += new System.EventHandler(this.ProtectionBot1_Click);
            // 
            // ForwarderBot1
            // 
            this.ForwarderBot1.BackColor = System.Drawing.Color.Cyan;
            this.ForwarderBot1.Checked = true;
            this.ForwarderBot1.CheckOnClick = true;
            this.ForwarderBot1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ForwarderBot1.Name = "ForwarderBot1";
            resources.ApplyResources(this.ForwarderBot1, "ForwarderBot1");
            this.ForwarderBot1.Click += new System.EventHandler(this.ForwarderBot1_Click);
            // 
            // AntiDCBot1
            // 
            this.AntiDCBot1.BackColor = System.Drawing.Color.Cyan;
            this.AntiDCBot1.Checked = true;
            this.AntiDCBot1.CheckOnClick = true;
            this.AntiDCBot1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AntiDCBot1.Name = "AntiDCBot1";
            resources.ApplyResources(this.AntiDCBot1, "AntiDCBot1");
            this.AntiDCBot1.Click += new System.EventHandler(this.AntiDCBot1_Click);
            // 
            // AntiFloodBot1
            // 
            this.AntiFloodBot1.BackColor = System.Drawing.Color.Cyan;
            this.AntiFloodBot1.Checked = true;
            this.AntiFloodBot1.CheckOnClick = true;
            this.AntiFloodBot1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AntiFloodBot1.Name = "AntiFloodBot1";
            resources.ApplyResources(this.AntiFloodBot1, "AntiFloodBot1");
            this.AntiFloodBot1.Click += new System.EventHandler(this.AntiFloodBot1_Click);
            // 
            // RoomBot1
            // 
            this.RoomBot1.BackColor = System.Drawing.Color.Cyan;
            this.RoomBot1.Checked = true;
            this.RoomBot1.CheckOnClick = true;
            this.RoomBot1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.RoomBot1.Name = "RoomBot1";
            resources.ApplyResources(this.RoomBot1, "RoomBot1");
            this.RoomBot1.Click += new System.EventHandler(this.RoomBot1_Click);
            // 
            // RoomFullerBot1
            // 
            this.RoomFullerBot1.BackColor = System.Drawing.Color.Cyan;
            this.RoomFullerBot1.Checked = true;
            this.RoomFullerBot1.CheckOnClick = true;
            this.RoomFullerBot1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.RoomFullerBot1.Name = "RoomFullerBot1";
            resources.ApplyResources(this.RoomFullerBot1, "RoomFullerBot1");
            this.RoomFullerBot1.Click += new System.EventHandler(this.RoomFullerBot1_Click);
            // 
            // OptimizerBot1
            // 
            this.OptimizerBot1.BackColor = System.Drawing.Color.Cyan;
            this.OptimizerBot1.Checked = true;
            this.OptimizerBot1.CheckOnClick = true;
            this.OptimizerBot1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.OptimizerBot1.Name = "OptimizerBot1";
            resources.ApplyResources(this.OptimizerBot1, "OptimizerBot1");
            this.OptimizerBot1.Click += new System.EventHandler(this.OptimizerBot1_Click);
            // 
            // MTA_Server
            // 
            this.MTA_Server.BackColor = System.Drawing.Color.Cyan;
            this.MTA_Server.Checked = true;
            this.MTA_Server.CheckOnClick = true;
            this.MTA_Server.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MTA_Server.Name = "MTA_Server";
            resources.ApplyResources(this.MTA_Server, "MTA_Server");
            this.MTA_Server.Click += new System.EventHandler(this.RoomFreezeRemoverBot1_Click);
            // 
            // myBotsToolStripMenuItem
            // 
            this.myBotsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.updateToolStripMenuItem});
            this.myBotsToolStripMenuItem.Name = "myBotsToolStripMenuItem";
            resources.ApplyResources(this.myBotsToolStripMenuItem, "myBotsToolStripMenuItem");
            // 
            // updateToolStripMenuItem
            // 
            this.updateToolStripMenuItem.BackColor = System.Drawing.Color.Aqua;
            this.updateToolStripMenuItem.Name = "updateToolStripMenuItem";
            resources.ApplyResources(this.updateToolStripMenuItem, "updateToolStripMenuItem");
            this.updateToolStripMenuItem.Click += new System.EventHandler(this.updateToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            resources.ApplyResources(this.toolStripMenuItem1, "toolStripMenuItem1");
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            resources.ApplyResources(this.exitToolStripMenuItem, "exitToolStripMenuItem");
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // coloroption
            // 
            this.coloroption.Name = "coloroption";
            resources.ApplyResources(this.coloroption, "coloroption");
            this.coloroption.Click += new System.EventHandler(this.coloroption_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tagsToolStripMenuItem,
            this.forumToolStripMenuItem,
            this.homeToolStripMenuItem});
            resources.ApplyResources(this.toolStripMenuItem4, "toolStripMenuItem4");
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // tagsToolStripMenuItem
            // 
            this.tagsToolStripMenuItem.BackColor = System.Drawing.Color.Aqua;
            this.tagsToolStripMenuItem.Name = "tagsToolStripMenuItem";
            resources.ApplyResources(this.tagsToolStripMenuItem, "tagsToolStripMenuItem");
            this.tagsToolStripMenuItem.Click += new System.EventHandler(this.tagsToolStripMenuItem_Click);
            // 
            // forumToolStripMenuItem
            // 
            this.forumToolStripMenuItem.BackColor = System.Drawing.Color.Aqua;
            this.forumToolStripMenuItem.Name = "forumToolStripMenuItem";
            resources.ApplyResources(this.forumToolStripMenuItem, "forumToolStripMenuItem");
            this.forumToolStripMenuItem.Click += new System.EventHandler(this.forumToolStripMenuItem_Click);
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.BackColor = System.Drawing.Color.Aqua;
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            resources.ApplyResources(this.homeToolStripMenuItem, "homeToolStripMenuItem");
            this.homeToolStripMenuItem.Click += new System.EventHandler(this.homeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            resources.ApplyResources(this.toolStripMenuItem3, "toolStripMenuItem3");
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click_1);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            resources.ApplyResources(this.toolStripMenuItem5, "toolStripMenuItem5");
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            resources.ApplyResources(this.aboutToolStripMenuItem, "aboutToolStripMenuItem");
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button4.FlatAppearance.BorderSize = 2;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            resources.ApplyResources(this.button4, "button4");
            this.button4.Name = "button4";
            this.toolTip1.SetToolTip(this.button4, resources.GetString("button4.ToolTip"));
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DodgerBlue;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button5.FlatAppearance.BorderSize = 2;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            resources.ApplyResources(this.button5, "button5");
            this.button5.Name = "button5";
            this.toolTip1.SetToolTip(this.button5, resources.GetString("button5.ToolTip"));
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox4
            // 
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.Name = "textBox4";
            // 
            // abooot
            // 
            resources.ApplyResources(this.abooot, "abooot");
            this.abooot.Name = "abooot";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Name = "label5";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Name = "label6";
            // 
            // hostcheck
            // 
            resources.ApplyResources(this.hostcheck, "hostcheck");
            this.hostcheck.BackColor = System.Drawing.Color.Transparent;
            this.hostcheck.ForeColor = System.Drawing.Color.Black;
            this.hostcheck.Name = "hostcheck";
            this.hostcheck.UseVisualStyleBackColor = false;
            this.hostcheck.CheckedChanged += new System.EventHandler(this.hostcheck_CheckedChanged);
            // 
            // richTextBox1
            // 
            resources.ApplyResources(this.richTextBox1, "richTextBox1");
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // reg
            // 
            resources.ApplyResources(this.reg, "reg");
            this.reg.Name = "reg";
            // 
            // user
            // 
            resources.ApplyResources(this.user, "user");
            this.user.Name = "user";
            this.user.TextChanged += new System.EventHandler(this.user_TextChanged);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Gray;
            this.button6.ContextMenuStrip = this.contextMenuStrip1;
            resources.ApplyResources(this.button6, "button6");
            this.button6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button6.Name = "button6";
            this.toolTip1.SetToolTip(this.button6, resources.GetString("button6.ToolTip"));
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Gray;
            this.button7.ContextMenuStrip = this.contextMenuStrip1;
            resources.ApplyResources(this.button7, "button7");
            this.button7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button7.Name = "button7";
            this.toolTip1.SetToolTip(this.button7, resources.GetString("button7.ToolTip"));
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // commandlist
            // 
            resources.ApplyResources(this.commandlist, "commandlist");
            this.commandlist.Name = "commandlist";
            this.commandlist.TextChanged += new System.EventHandler(this.commandlist_TextChanged);
            // 
            // commandmsglist
            // 
            resources.ApplyResources(this.commandmsglist, "commandmsglist");
            this.commandmsglist.Name = "commandmsglist";
            // 
            // tagstimer
            // 
            this.tagstimer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.listBox1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.listBox1.FormattingEnabled = true;
            resources.ApplyResources(this.listBox1, "listBox1");
            this.listBox1.Name = "listBox1";
            this.toolTip1.SetToolTip(this.listBox1, resources.GetString("listBox1.ToolTip"));
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged_1);
            this.listBox1.DoubleClick += new System.EventHandler(this.listBox1_DoubleClick);
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.listBox2.ForeColor = System.Drawing.Color.GreenYellow;
            this.listBox2.FormattingEnabled = true;
            resources.ApplyResources(this.listBox2, "listBox2");
            this.listBox2.Name = "listBox2";
            this.toolTip1.SetToolTip(this.listBox2, resources.GetString("listBox2.ToolTip"));
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            this.listBox2.DoubleClick += new System.EventHandler(this.listBox2_DoubleClick);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 3600000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick_1);
            // 
            // adminhelp
            // 
            resources.ApplyResources(this.adminhelp, "adminhelp");
            this.adminhelp.Name = "adminhelp";
            // 
            // radioButton1
            // 
            resources.ApplyResources(this.radioButton1, "radioButton1");
            this.radioButton1.BackColor = System.Drawing.Color.Lime;
            this.radioButton1.Checked = true;
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton1, resources.GetString("radioButton1.ToolTip"));
            this.radioButton1.UseVisualStyleBackColor = false;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton3
            // 
            resources.ApplyResources(this.radioButton3, "radioButton3");
            this.radioButton3.BackColor = System.Drawing.Color.OrangeRed;
            this.radioButton3.Name = "radioButton3";
            this.toolTip1.SetToolTip(this.radioButton3, resources.GetString("radioButton3.ToolTip"));
            this.radioButton3.UseVisualStyleBackColor = false;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            resources.ApplyResources(this.radioButton4, "radioButton4");
            this.radioButton4.BackColor = System.Drawing.Color.Red;
            this.radioButton4.Name = "radioButton4";
            this.toolTip1.SetToolTip(this.radioButton4, resources.GetString("radioButton4.ToolTip"));
            this.radioButton4.UseVisualStyleBackColor = false;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.DarkRed;
            resources.ApplyResources(this.button8, "button8");
            this.button8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button8.Name = "button8";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // NetFreeCheckBox
            // 
            resources.ApplyResources(this.NetFreeCheckBox, "NetFreeCheckBox");
            this.NetFreeCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.NetFreeCheckBox.ForeColor = System.Drawing.Color.Black;
            this.NetFreeCheckBox.Name = "NetFreeCheckBox";
            this.toolTip1.SetToolTip(this.NetFreeCheckBox, resources.GetString("NetFreeCheckBox.ToolTip"));
            this.NetFreeCheckBox.UseVisualStyleBackColor = true;
            // 
            // timer4
            // 
            this.timer4.Interval = 3000;
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // ErrorLable
            // 
            this.ErrorLable.BackColor = System.Drawing.Color.LightPink;
            this.ErrorLable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ErrorLable.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.ErrorLable, "ErrorLable");
            this.ErrorLable.Name = "ErrorLable";
            // 
            // toolTip1
            // 
            this.toolTip1.AutoPopDelay = 30000;
            this.toolTip1.InitialDelay = 100;
            this.toolTip1.ReshowDelay = 100;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Tip";
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.SpringGreen;
            this.button11.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button11.FlatAppearance.BorderSize = 2;
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            resources.ApplyResources(this.button11, "button11");
            this.button11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button11.Name = "button11";
            this.toolTip1.SetToolTip(this.button11, resources.GetString("button11.ToolTip"));
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.DarkRed;
            resources.ApplyResources(this.button12, "button12");
            this.button12.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button12.Name = "button12";
            this.toolTip1.SetToolTip(this.button12, resources.GetString("button12.ToolTip"));
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // checkBox3
            // 
            resources.ApplyResources(this.checkBox3, "checkBox3");
            this.checkBox3.BackColor = System.Drawing.Color.Transparent;
            this.checkBox3.Checked = true;
            this.checkBox3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox3.ForeColor = System.Drawing.Color.Black;
            this.checkBox3.Name = "checkBox3";
            this.toolTip1.SetToolTip(this.checkBox3, resources.GetString("checkBox3.ToolTip"));
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // button00
            // 
            this.button00.BackColor = System.Drawing.Color.Teal;
            this.button00.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button00.FlatAppearance.BorderSize = 2;
            this.button00.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            resources.ApplyResources(this.button00, "button00");
            this.button00.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button00.Name = "button00";
            this.toolTip1.SetToolTip(this.button00, resources.GetString("button00.ToolTip"));
            this.button00.UseVisualStyleBackColor = false;
            this.button00.Click += new System.EventHandler(this.button9_Click_1);
            // 
            // forwadercpanle
            // 
            resources.ApplyResources(this.forwadercpanle, "forwadercpanle");
            this.forwadercpanle.Name = "forwadercpanle";
            this.forwadercpanle.TextChanged += new System.EventHandler(this.forwadercpanle_TextChanged);
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // button10
            // 
            resources.ApplyResources(this.button10, "button10");
            this.button10.Name = "button10";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click_1);
            // 
            // originalHELP
            // 
            resources.ApplyResources(this.originalHELP, "originalHELP");
            this.originalHELP.Name = "originalHELP";
            this.originalHELP.TextChanged += new System.EventHandler(this.originalHELP_TextChanged);
            // 
            // WaringLabel
            // 
            resources.ApplyResources(this.WaringLabel, "WaringLabel");
            this.WaringLabel.BackColor = System.Drawing.Color.MintCream;
            this.WaringLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.WaringLabel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.WaringLabel.Name = "WaringLabel";
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // childbotcommands
            // 
            resources.ApplyResources(this.childbotcommands, "childbotcommands");
            this.childbotcommands.Name = "childbotcommands";
            this.childbotcommands.TextChanged += new System.EventHandler(this.childbotcommands_TextChanged);
            // 
            // childbotEng
            // 
            resources.ApplyResources(this.childbotEng, "childbotEng");
            this.childbotEng.Name = "childbotEng";
            // 
            // hlp
            // 
            resources.ApplyResources(this.hlp, "hlp");
            this.hlp.Name = "hlp";
            // 
            // hlp2
            // 
            resources.ApplyResources(this.hlp2, "hlp2");
            this.hlp2.Name = "hlp2";
            // 
            // spOriginalHELP
            // 
            resources.ApplyResources(this.spOriginalHELP, "spOriginalHELP");
            this.spOriginalHELP.Name = "spOriginalHELP";
            // 
            // timer3
            // 
            this.timer3.Enabled = true;
            this.timer3.Interval = 1000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.Controls.Add(this.hlp);
            this.Controls.Add(this.button00);
            this.Controls.Add(this.spOriginalHELP);
            this.Controls.Add(this.hlp2);
            this.Controls.Add(this.childbotEng);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.childbotcommands);
            this.Controls.Add(this.originalHELP);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.WaringLabel);
            this.Controls.Add(this.ErrorLable);
            this.Controls.Add(this.NetFreeCheckBox);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.forwadercpanle);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.adminhelp);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.user);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.commandlist);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.commandmsglist);
            this.Controls.Add(this.reg);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.hostcheck);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.abooot);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.messg);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.sts);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.master);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.eng);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Opacity = 0.85;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseEnter += new System.EventHandler(this.Form1_MouseEnter);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion
        private System.Windows.Forms.TextBox master;
        private System.Windows.Forms.TextBox eng;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox sts;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label messg;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.RichTextBox abooot;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox hostcheck;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox reg;
        private System.Windows.Forms.TextBox user;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.RichTextBox commandlist;
        private System.Windows.Forms.RichTextBox commandmsglist;
        private System.Windows.Forms.Timer tagstimer;
        private System.Windows.Forms.ToolStripMenuItem tagsToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.RichTextBox adminhelp;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem forumToolStripMenuItem;
        private System.Windows.Forms.CheckBox NetFreeCheckBox;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Label ErrorLable;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem ChildBot1;
        private System.Windows.Forms.ToolStripMenuItem ProtectionBot1;
        private System.Windows.Forms.ToolStripMenuItem ForwarderBot1;
        private System.Windows.Forms.ToolStripMenuItem AntiDCBot1;
        private System.Windows.Forms.ToolStripMenuItem AntiFloodBot1;
        private System.Windows.Forms.ToolStripMenuItem RoomBot1;
        private System.Windows.Forms.ToolStripMenuItem RoomFullerBot1;
        private System.Windows.Forms.ToolStripMenuItem OptimizerBot1;
        private System.Windows.Forms.ToolStripMenuItem MTA_Server;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.RichTextBox forwadercpanle;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ToolStripMenuItem cpanelToolStripMenuItem;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.ToolStripMenuItem myBotsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateToolStripMenuItem;
        private System.Windows.Forms.RichTextBox originalHELP;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.Label WaringLabel;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.ToolStripMenuItem coloroption;
        private System.Windows.Forms.RichTextBox childbotcommands;
        private System.Windows.Forms.RichTextBox childbotEng;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.RichTextBox hlp;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.RichTextBox hlp2;
        private System.Windows.Forms.RichTextBox spOriginalHELP;
        private System.Windows.Forms.Button button00;
        private System.Windows.Forms.Timer timer3;
    }
}
