﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Drawing;
namespace Nizzc_Collection
{
    class Animation
    {
     public void main()
        {
        }
        private void timer3_Tick(object sender, EventArgs e)
        {
        }
    }
}
